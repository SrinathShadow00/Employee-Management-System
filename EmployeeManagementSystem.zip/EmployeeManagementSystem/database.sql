CREATE DATABASE IF NOT EXISTS employee_db;

USE employee_db;

CREATE TABLE IF NOT EXISTS employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20),
    department VARCHAR(50),
    designation VARCHAR(50),
    salary DECIMAL(10, 2),
    hire_date DATE,
    employee_type VARCHAR(20) NOT NULL DEFAULT 'EMPLOYEE',
    team_name VARCHAR(50)
);