package com.ems.model;

import java.time.LocalDate;

public class Employee {

    protected int id;
    protected String name;
    protected String email;
    protected String phone;
    protected String department;
    protected String designation;
    protected double salary;
    protected LocalDate hireDate;

    public Employee() {
    }

    public Employee(int id, String name, String email, String phone, String department,
                    String designation, double salary, LocalDate hireDate) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.department = department;
        this.designation = designation;
        this.salary = salary;
        this.hireDate = hireDate;
    }

    public String getEmployeeType() {
        return "EMPLOYEE";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public LocalDate getHireDate() {
        return hireDate;
    }

    public void setHireDate(LocalDate hireDate) {
        this.hireDate = hireDate;
    }

    @Override
    public String toString() {
        return "Employee [id=" + id + ", name=" + name + ", email=" + email + ", phone=" + phone
                + ", department=" + department + ", designation=" + designation
                + ", salary=" + salary + ", hireDate=" + hireDate + ", type=" + getEmployeeType() + "]";
    }
}