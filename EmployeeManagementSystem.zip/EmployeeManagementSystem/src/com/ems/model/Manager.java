package com.ems.model;

import java.time.LocalDate;

public class Manager extends Employee {

    private String teamName;

    public Manager() {
    }

    public Manager(int id, String name, String email, String phone, String department,
                   String designation, double salary, LocalDate hireDate, String teamName) {
        super(id, name, email, phone, department, designation, salary, hireDate);
        this.teamName = teamName;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    @Override
    public String getEmployeeType() {
        return "MANAGER";
    }

    @Override
    public String toString() {
        return "Manager [id=" + id + ", name=" + name + ", email=" + email + ", phone=" + phone
                + ", department=" + department + ", designation=" + designation
                + ", salary=" + salary + ", hireDate=" + hireDate
                + ", teamName=" + teamName + "]";
    }
}