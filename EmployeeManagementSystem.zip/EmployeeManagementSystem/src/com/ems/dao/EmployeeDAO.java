package com.ems.dao;

import com.ems.model.Employee;

import java.util.List;

public interface EmployeeDAO {

    boolean create(Employee employee);

    Employee findById(int id);

    List<Employee> findAll();

    List<Employee> search(String keyword);

    boolean update(Employee employee);

    boolean delete(int id);

    int count();
}