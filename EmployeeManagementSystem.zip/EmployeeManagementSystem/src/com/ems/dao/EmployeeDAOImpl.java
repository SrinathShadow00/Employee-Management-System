package com.ems.dao;

import com.ems.db.DBConnection;
import com.ems.model.Employee;
import com.ems.model.Manager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAOImpl implements EmployeeDAO {

    private static final String INSERT_SQL =
            "INSERT INTO employees (name, email, phone, department, designation, salary, hire_date, employee_type, team_name) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String SELECT_BY_ID_SQL =
            "SELECT * FROM employees WHERE id = ?";

    private static final String SELECT_ALL_SQL =
            "SELECT * FROM employees ORDER BY id";

    private static final String SEARCH_SQL =
            "SELECT * FROM employees WHERE name LIKE ? OR email LIKE ? OR department LIKE ? OR designation LIKE ? ORDER BY id";

    private static final String UPDATE_SQL =
            "UPDATE employees SET name = ?, email = ?, phone = ?, department = ?, designation = ?, "
                    + "salary = ?, hire_date = ?, employee_type = ?, team_name = ? WHERE id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM employees WHERE id = ?";

    private static final String COUNT_SQL =
            "SELECT COUNT(*) FROM employees";

    @Override
    public boolean create(Employee employee) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(INSERT_SQL)) {
            bindCommon(statement, employee);
            statement.setString(9, getTeamName(employee));
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to create employee record.", e);
        }
    }

    @Override
    public Employee findById(int id) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_BY_ID_SQL)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return mapRow(resultSet);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to search employee by id.", e);
        }
        return null;
    }

    @Override
    public List<Employee> findAll() {
        List<Employee> employees = new ArrayList<>();
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_ALL_SQL);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                employees.add(mapRow(resultSet));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to load employees.", e);
        }
        return employees;
    }

    @Override
    public List<Employee> search(String keyword) {
        List<Employee> employees = new ArrayList<>();
        String pattern = "%" + keyword + "%";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(SEARCH_SQL)) {
            statement.setString(1, pattern);
            statement.setString(2, pattern);
            statement.setString(3, pattern);
            statement.setString(4, pattern);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    employees.add(mapRow(resultSet));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to search employees.", e);
        }
        return employees;
    }

    @Override
    public boolean update(Employee employee) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_SQL)) {
            bindCommon(statement, employee);
            statement.setString(9, getTeamName(employee));
            statement.setInt(10, employee.getId());
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to update employee record.", e);
        }
    }

    @Override
    public boolean delete(int id) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_SQL)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to delete employee record.", e);
        }
    }

    @Override
    public int count() {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(COUNT_SQL);
             ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to count employees.", e);
        }
        return 0;
    }

    private void bindCommon(PreparedStatement statement, Employee employee) throws SQLException {
        statement.setString(1, employee.getName());
        statement.setString(2, employee.getEmail());
        statement.setString(3, employee.getPhone());
        statement.setString(4, employee.getDepartment());
        statement.setString(5, employee.getDesignation());
        statement.setDouble(6, employee.getSalary());
        statement.setDate(7, employee.getHireDate() != null
                ? java.sql.Date.valueOf(employee.getHireDate()) : null);
        statement.setString(8, employee.getEmployeeType());
    }

    private String getTeamName(Employee employee) {
        return employee instanceof Manager ? ((Manager) employee).getTeamName() : null;
    }

    private Employee mapRow(ResultSet resultSet) throws SQLException {
        String type = resultSet.getString("employee_type");
        Employee employee;
        if ("MANAGER".equals(type)) {
            Manager manager = new Manager();
            manager.setTeamName(resultSet.getString("team_name"));
            employee = manager;
        } else {
            employee = new Employee();
        }
        fillCommon(employee, resultSet);
        return employee;
    }

    private void fillCommon(Employee employee, ResultSet resultSet) throws SQLException {
        employee.setId(resultSet.getInt("id"));
        employee.setName(resultSet.getString("name"));
        employee.setEmail(resultSet.getString("email"));
        employee.setPhone(resultSet.getString("phone"));
        employee.setDepartment(resultSet.getString("department"));
        employee.setDesignation(resultSet.getString("designation"));
        employee.setSalary(resultSet.getDouble("salary"));
        java.sql.Date hireDate = resultSet.getDate("hire_date");
        employee.setHireDate(hireDate != null ? hireDate.toLocalDate() : null);
    }
}