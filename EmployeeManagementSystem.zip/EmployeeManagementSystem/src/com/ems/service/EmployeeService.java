package com.ems.service;

import com.ems.dao.EmployeeDAO;
import com.ems.dao.EmployeeDAOImpl;
import com.ems.model.Employee;

import java.util.List;
import java.util.regex.Pattern;

public class EmployeeService {

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");

    private final EmployeeDAO employeeDAO;

    public EmployeeService() {
        this.employeeDAO = new EmployeeDAOImpl();
    }

    public boolean addEmployee(Employee employee) {
        validate(employee);
        return employeeDAO.create(employee);
    }

    public Employee getEmployeeById(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("Employee id must be a positive number.");
        }
        return employeeDAO.findById(id);
    }

    public List<Employee> getAllEmployees() {
        return employeeDAO.findAll();
    }

    public List<Employee> searchEmployees(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            throw new IllegalArgumentException("Search keyword cannot be empty.");
        }
        return employeeDAO.search(keyword.trim());
    }

    public boolean updateEmployee(Employee employee) {
        if (employee == null || employee.getId() <= 0) {
            throw new IllegalArgumentException("A valid employee with id is required for update.");
        }
        validate(employee);
        return employeeDAO.update(employee);
    }

    public boolean deleteEmployee(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("Employee id must be a positive number.");
        }
        return employeeDAO.delete(id);
    }

    public int getEmployeeCount() {
        return employeeDAO.count();
    }

    private void validate(Employee employee) {
        if (employee == null) {
            throw new IllegalArgumentException("Employee cannot be null.");
        }
        if (employee.getName() == null || employee.getName().isBlank()) {
            throw new IllegalArgumentException("Name cannot be empty.");
        }
        if (employee.getEmail() == null
                || !EMAIL_PATTERN.matcher(employee.getEmail()).matches()) {
            throw new IllegalArgumentException("Invalid email format.");
        }
        if (employee.getDepartment() == null || employee.getDepartment().isBlank()) {
            throw new IllegalArgumentException("Department cannot be empty.");
        }
        if (employee.getSalary() <= 0) {
            throw new IllegalArgumentException("Salary must be greater than zero.");
        }
    }
}