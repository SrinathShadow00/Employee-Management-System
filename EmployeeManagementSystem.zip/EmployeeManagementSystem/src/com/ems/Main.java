package com.ems;

import com.ems.db.DBConnection;
import com.ems.model.Employee;
import com.ems.model.Manager;
import com.ems.service.EmployeeService;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static final Scanner SCANNER = new Scanner(System.in);
    private static final EmployeeService SERVICE = new EmployeeService();

    public static void main(String[] args) {
        System.out.println("========== EMPLOYEE MANAGEMENT SYSTEM ==========");
        boolean running = true;
        while (running) {
            try {
                printMenu();
                int choice = readInt("Enter your choice: ");
                switch (choice) {
                    case 1 -> addEmployee();
                    case 2 -> viewAllEmployees();
                    case 3 -> searchEmployees();
                    case 4 -> updateEmployee();
                    case 5 -> deleteEmployee();
                    case 6 -> System.out.println("Total employees: " + SERVICE.getEmployeeCount());
                    case 0 -> running = false;
                    default -> System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        DBConnection.closeConnection();
        SCANNER.close();
        System.out.println("Application closed. Goodbye!");
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("---- Main Menu ----");
        System.out.println("1. Add employee");
        System.out.println("2. View all employees");
        System.out.println("3. Search employees");
        System.out.println("4. Update employee");
        System.out.println("5. Delete employee");
        System.out.println("6. Employee count");
        System.out.println("0. Exit");
    }

    private static void addEmployee() {
        System.out.println("\n--- Add New Employee ---");
        Employee employee;
        if (readInt("Employee type (1 = Employee, 2 = Manager): ") == 2) {
            Manager manager = new Manager();
            manager.setTeamName(readString("Team name: "));
            employee = manager;
        } else {
            employee = new Employee();
        }
        employee.setName(readString("Name: "));
        employee.setEmail(readString("Email: "));
        employee.setPhone(readString("Phone: "));
        employee.setDepartment(readString("Department: "));
        employee.setDesignation(readString("Designation: "));
        employee.setSalary(readDouble("Salary: "));
        employee.setHireDate(readDate("Hire date (yyyy-MM-dd): "));

        boolean created = SERVICE.addEmployee(employee);
        System.out.println(created ? "Employee added successfully." : "Failed to add employee.");
    }

    private static void viewAllEmployees() {
        System.out.println("\n--- All Employees ---");
        List<Employee> employees = SERVICE.getAllEmployees();
        if (employees.isEmpty()) {
            System.out.println("No employees found.");
            return;
        }
        for (Employee employee : employees) {
            System.out.println(employee);
        }
        System.out.println("Total: " + employees.size());
    }

    private static void searchEmployees() {
        System.out.println("\n--- Search Employees ---");
        String keyword = readString("Search keyword (name/email/department/designation): ");
        List<Employee> results = SERVICE.searchEmployees(keyword);
        if (results.isEmpty()) {
            System.out.println("No employees match: " + keyword);
            return;
        }
        for (Employee employee : results) {
            System.out.println(employee);
        }
        System.out.println("Matches: " + results.size());
    }

    private static void updateEmployee() {
        System.out.println("\n--- Update Employee ---");
        int id = readInt("Enter employee id to update: ");
        Employee existing = SERVICE.getEmployeeById(id);
        if (existing == null) {
            System.out.println("No employee found with id " + id + ".");
            return;
        }

        Employee updated = existing instanceof Manager ? new Manager() : new Employee();
        updated.setId(existing.getId());
        if (updated instanceof Manager manager && existing instanceof Manager existingManager) {
            manager.setTeamName(readOrKeep("Team name", existingManager.getTeamName()));
        }
        updated.setName(readOrKeep("Name", existing.getName()));
        updated.setEmail(readOrKeep("Email", existing.getEmail()));
        updated.setPhone(readOrKeep("Phone", existing.getPhone()));
        updated.setDepartment(readOrKeep("Department", existing.getDepartment()));
        updated.setDesignation(readOrKeep("Designation", existing.getDesignation()));
        updated.setSalary(readPositiveNumber("Salary", existing.getSalary()));
        updated.setHireDate(readDateOrKeep("Hire date (yyyy-MM-dd)", existing.getHireDate()));

        boolean updatedFlag = SERVICE.updateEmployee(updated);
        System.out.println(updatedFlag
                ? "Employee updated successfully."
                : "No changes were saved.");
    }

    private static void deleteEmployee() {
        System.out.println("\n--- Delete Employee ---");
        int id = readInt("Enter employee id to delete: ");
        Employee existing = SERVICE.getEmployeeById(id);
        if (existing == null) {
            System.out.println("No employee found with id " + id + ".");
            return;
        }
        System.out.println("Record: " + existing);
        String confirmation = readString("Are you sure you want to delete this employee? (y/n): ");
        if (!"y".equalsIgnoreCase(confirmation)) {
            System.out.println("Deletion cancelled.");
            return;
        }
        boolean deleted = SERVICE.deleteEmployee(id);
        System.out.println(deleted ? "Employee deleted successfully." : "Failed to delete employee.");
    }

    private static String readOrKeep(String label, String currentValue) {
        String input = readString(label + " (" + currentValue + "): ");
        return input.isEmpty() ? currentValue : input;
    }

    private static double readPositiveNumber(String label, double currentValue) {
        System.out.print(label + " (" + currentValue + "): ");
        String input = SCANNER.nextLine().trim();
        if (input.isEmpty()) {
            return currentValue;
        }
        try {
            return Double.parseDouble(input);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid number entered.");
        }
    }

    private static LocalDate readDateOrKeep(String label, LocalDate currentValue) {
        System.out.print(label + " (" + currentValue + "): ");
        String input = SCANNER.nextLine().trim();
        if (input.isEmpty()) {
            return currentValue;
        }
        return readDate(label);
    }

    private static LocalDate readDate(String label) {
        System.out.print(label + ": ");
        String input = SCANNER.nextLine().trim();
        try {
            return input.isEmpty() ? LocalDate.now() : LocalDate.parse(input);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Invalid date. Expected format yyyy-MM-dd.");
        }
    }

    private static String readString(String prompt) {
        System.out.print(prompt);
        return SCANNER.nextLine().trim();
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                int value = SCANNER.nextInt();
                SCANNER.nextLine();
                return value;
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid number.");
                SCANNER.nextLine();
            }
        }
    }

    private static double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                double value = SCANNER.nextDouble();
                SCANNER.nextLine();
                return value;
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid number.");
                SCANNER.nextLine();
            }
        }
    }
}